import initialize from './initialize';
import logPageView from './logPageView';

export {
  initialize,
  logPageView
};
