export default {
  trackerId: 'UA-99690204-1',
  debug: false
};
